#' @title blacklist  file for example
#' @docType data
#' @name blacklist
#' @keywords d dataset
#'
NULL

#' @title GeneGTF  file
#' @docType data
#' @name GeneGTF
#' @keywords d dataset
NULL

#' @title pwms(pfms) matrix object
#' @docType data
#' @name pwms
#' @keywords d dataset
#'
NULL
